import boto3,requests

installer_api_key = "220F10A53E3CF0098DC836AA43AEC1EC27ED4EF9B0C9A33E8C78313A5DCE2CD7"
new_relic_gql_endpont = "https://api.newrelic.com/graphql"
apiKey = "NRAK-39TU7X6EWS68WNH40PCJ675N21Q"
example_query = '''{
   actor {
      account(id: 3257316) {
         nrql(query: "SELECT count(*) FROM Transaction SINCE 1 HOUR AGO") {
            results
         }
      }
   }
}'''

def post_request():
    requests.psost

headers = { 'Content-Type': 'application/json',
      'API-KEY': installer_api_key}

      
def lambda_handler():
    pass




# https://api.newrelic.com/graphql


    # https://docs.newrelic.com/docs/apis/nerdgraph/get-started/introduction-new-relic-nerdgraph/#explorer
